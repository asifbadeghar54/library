<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
| example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
| https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
| $route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
| $route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
| $route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples: my-controller/index -> my_controller/index
| my-controller/my-method -> my_controller/my_method
*/
$route['default_controller'] = 'welcome';
$route['404_override'] = 'PageNotFound';
$route['translate_uri_dashes'] = FALSE;


$route['admin_controller'] = 'Admin';
$route['admin-logout']= $route['admin_controller'].'/sessionDestroy';
$route['verify-admin-login']= $route['admin_controller'].'/verifyAdminLogin';
$route['admin']= $route['admin_controller'].'/adminLogin';
$route['admin-dashboard']= $route['admin_controller'].'/adminDashboard';
$route['authorize-user/(:any)']= $route['admin_controller'].'/authorizeUser/$1';
$route['admin-view-users']= $route['admin_controller'].'/viewUser';
$route['admin-view-post']= $route['admin_controller'].'/viewPost';

$route['admin-add-post']= $route['admin_controller'].'/addPost';
$route['admin-insert-post']= $route['admin_controller'].'/insertPost';
$route['admin-edit-post/(:any)']= $route['admin_controller'].'/editPost/$1';
$route['admin-update-post/(:any)']= $route['admin_controller'].'/updatePost/$1';
$route['admin-delete-post/(:any)']= $route['admin_controller'].'/deletePost/$1';
$route['admin-view-users']= $route['admin_controller'].'/viewUser';

$route['admin-add-user']= $route['admin_controller'].'/addUser';
$route['admin-insert-user']= $route['admin_controller'].'/insertUser';
$route['admin-edit-user/(:any)']= $route['admin_controller'].'/editUser/$1';
$route['admin-update-user/(:any)']= $route['admin_controller'].'/updateUser/$1';
$route['admin-delete-user/(:any)']= $route['admin_controller'].'/deleteUser/$1';



$route['login']= $route['default_controller'].'/login';
$route['verify-login']= $route['default_controller'].'/verifyLogin';
$route['posts']= $route['default_controller'].'/postsList';
$route['single-post/(:any)']= $route['default_controller'].'/singlePost/$1';
$route['logout']= $route['default_controller'].'/sessionDestroy';
$route['sign-up']= $route['default_controller'].'/signUp';
$route['user-dashboard']= $route['default_controller'].'/userDashboard';
$route['view-post']= $route['default_controller'].'/viewPost';
$route['add-post']= $route['default_controller'].'/addPost';
$route['insert-post']= $route['default_controller'].'/insertPost';
$route['edit-post/(:any)']= $route['default_controller'].'/editPost/$1';
$route['update-post/(:any)']= $route['default_controller'].'/updatePost/$1';
$route['delete-post/(:any)']= $route['default_controller'].'/deletePost/$1';

$route['view-users']= $route['default_controller'].'/viewUser';
$route['add-user']= $route['default_controller'].'/addUser';
$route['insert-user']= $route['default_controller'].'/insertUser';
$route['edit-user/(:any)']= $route['default_controller'].'/editUser/$1';
$route['update-user/(:any)']= $route['default_controller'].'/updateUser/$1';
$route['delete-user/(:any)']= $route['default_controller'].'/deleteUser/$1';

