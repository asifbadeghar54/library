<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class Admin extends CI_Controller {

/**

* Index Page for this controller.

*

* Maps to the following URL

* http://example.com/index.php/welcome

* - or -

* http://example.com/index.php/welcome/index

* - or -

* Since this controller is set as the default controller in

* config/routes.php, it's displayed at http://example.com/

*

* So any other public methods not prefixed with an underscore will

* map to /index.php/welcome/<method_name>

* @see https://codeigniter.com/user_guide/general/urls.html

*/

// public function index()

// {

// $this->load->view('welcome_message');

// }

public function adminLogin()

{

	$this->load->view('admin/admin_login');

}

public function verifyAdminLogin() 

{

// print_r("hi");exit;

 $username = $this->input->post('username');

 $password = $this->input->post('password');

  // $remember=$this->input->post('rememberme');

 $login_user_details = $this->Admin_model->verifyAdminLogin($username);

 if ($login_user_details->num_rows() > 0) {

   $login_user_details = $login_user_details->row();

   if ($login_user_details->password == $password) {

     $_SESSION['admin_username'] = $login_user_details->username;

     $_SESSION['admin_role'] = $login_user_details->role;

     $_SESSION['admin_fname'] = $login_user_details->first_name;

     $_SESSION['admin_lname'] = $login_user_details->last_name;
     $this->session->set_flashdata('login-success', 'login success...');
     redirect('admin-dashboard');
  } else {
     $this->session->set_flashdata('incorrect-password-error', 'incorrect password!!!');
     redirect('admin');
  }

} else {

  $this->session->set_flashdata('no-account-found-error', 'no account found with this username..');

  redirect('admin');

}

}

public function sessionDestroy() 

{

 if (!$this->session->userdata('admin_username')) redirect('login');

 $this->session->set_flashdata('logout-success', 'logout successfully');

  // $this->session->unset_userdata('id');

 $this->session->unset_userdata('admin_username');

 $this->session->unset_userdata('admin_role');

 $this->session->unset_userdata('admin_fname');

 $this->session->unset_userdata('admin_lname');

 

 redirect('');

}

// public function signUp()

// {

// 	$this->load->view('library/signup');

// }

public function adminDashboard()

{

   if (!$this->session->userdata('admin_username')) redirect('admin');

   $data['total'] =$this->Admin_model->getNumberOFPosts();

   $data['totalUser'] =$this->Admin_model->   getNumberOFUsers();



   $this->load->view('admin/header');

   $this->load->view('admin/home',$data);

   $this->load->view('admin/footer');

}

public function viewPost()

{

   if (!$this->session->userdata('admin_username')) redirect('login');

   $data['post_details'] = $this->Admin_model->getPost();

   $this->load->view('admin/header');



   $this->load->view('admin/view_post',$data);

   $this->load->view('admin/footer');



}

public function addPost()

{

   if (!$this->session->userdata('admin_username')) redirect('login');

   $this->load->view('admin/header');

   $this->load->view('admin/post');

   $this->load->view('admin/footer');

}

public function insertPost()

{

	$this->Admin_model->insertPost();

}

public function editPost($id)

{

  if (!$this->session->userdata('admin_username')) redirect('login');

  $data['singlePost'] = $this->Admin_model->getPostDetails($id);

  $this->load->view('admin/header');

  $this->load->view('admin/edit_post', $data);		

  $this->load->view('admin/footer');

}

public function updatePost($id){

	

 $this->load->view('admin/header');

 $this->Admin_model->updatePost($id);

 $this->load->view('admin/footer');

}

public function deletePost($id){

   if (!$this->session->userdata('admin_username')) redirect('login');

   $this->Admin_model->deletePost($id);

}

public function authorizeUser($id){

 $this->Admin_model->authorizeUser($id);

}

// USers

public function viewUser()

{

   if (!$this->session->userdata('admin_username')) redirect('login');

   $data['user_details'] = $this->Admin_model->getUser();

   $this->load->view('admin/header');

   $this->load->view('admin/view_user',$data);

   $this->load->view('admin/footer');

}

public function addUSer()

{

   if (!$this->session->userdata('admin_username')) redirect('login');

   $this->load->view('admin/header');

   $this->load->view('admin/user');

   $this->load->view('admin/footer');

}

public function insertUser()

{

   if (!$this->session->userdata('admin_username')) redirect('login');

   $this->Admin_model->insertUser();

}

public function editUser($id)

{

  if (!$this->session->userdata('admin_username')) redirect('login');

  $data['singleUser'] = $this->Admin_model->getUserDetail($id);

  $this->load->view('admin/header');

  $this->load->view('admin/edit_user', $data);		

  $this->load->view('admin/footer');

}

public function updateUser($id){

   if (!$this->session->userdata('admin_username')) redirect('login');

   $this->Admin_model->updateUser($id);

}

public function deleteUser($id){

 if (!$this->session->userdata('admin_username')) redirect('login');

 $this->Admin_model->deleteUser($id);

}

}?>