<?php

defined('BASEPATH') OR exit ('No direct script access allowed');
class Admin_model extends CI_Model {
	public function insertPost(){
		if($this->input->post('title')){
			$data =array(
				'title'=>$this->input->post('title'),				
				'date'=>$this->input->post('date'),
				'content'=>$this->input->post('content'),
				'description'=>$this->input->post('description'),
				'auther'=>$this->input->post('auther'),
				'datetime'=>date('Y-m-d H-i-sA'),
				'added_by'=>$this->session->userdata('admin_fname')
			);
			$result=$this->db->insert('post',$data);
			if($result!=null)
			{
				$this->session->set_flashdata('add-post', 'success!!!');
				redirect('admin-view-post');
			}
		}
	}


public function getPost(){
	$query = $this->db->order_by('datetime',"desc")->get('post');
	if ($query) {
		return $query->result();
	}
}
public function getPostDetails($id){
	$this->db->where('id',$id);
	$query = $this->db->get('post');
	if ($query) {
		return $query->row();
	}
}

public function getNumberOFPosts()
{
	return $this->db->get('post')->num_rows();
}
public function getNumberOFUsers()
{
	return $this->db->get('user')->num_rows();
}

public function verifyUsername($id)
{
	return $this->db->where('email',$id)->where('authorized',1)->get('user');
}
public function verifyAdminLogin($id)
{
	$result=$this->db->where('username',$id)->get('admin');
    return $result;
}
public function updatePost($id){
	if($this->input->post('title')){
		$data =array(
			'title'=>$this->input->post('title'),				
			'date'=>$this->input->post('date'),
			'content'=>$this->input->post('content'),
			'description'=>$this->input->post('description'),
			'auther'=>$this->input->post('auther'),
            'datetime'=>date('Y-m-d H-i-sA'),
            'added_by'=>$this->session->userdata('admin_fname')
		);
		$this->db->where('id',$id);
		$result=$this->db->update('post',$data);
		if($result)
		{
			$this->session->set_flashdata('update-post', 'success!!!');
			redirect('admin-view-post');
		}
	}
}
public function getSinglePosts($id)
{
	return $this->db->where('id',$id)->get('post')->row();
}
public function deletePost($id)
{
	$this->db->where('id', $id);
	$result=$this->db->delete('post');
	if($result!=null)
	{
		$this->session->set_flashdata('delete-post', 'success!!!');
		redirect('admin-view-post');
	}
	
}

public function authorizeUser($id)
{
	$this->db->set('authorized',1)->where('id', $id);
	$result=$this->db->update('user');
	if($result!=null)
	{
		$this->session->set_flashdata('user-authorize', 'success!!!');
		redirect('admin-view-users');
	}
}

public function getUser(){
	$query = $this->db->where('role',0)->get('user');
	if ($query) {
		return $query->result();
	}
}
public function getUserDetail($id){
	$this->db->where('id',$id);
	$query = $this->db->order_by('datetime','desc')->get('user');
	if ($query) {
		return $query->row();
	}
}

public function updateUser($id){
	if($this->input->post('fname')){
		$data =array(
			'first_name'=>$this->input->post('fname'),				
			'last_name'=>$this->input->post('lname'),
			'email'=>$this->input->post('email'),
			'password'=>$this->input->post('password')				
		);
		$this->db->where('id',$id);
		$result=$this->db->update('user',$data);
		if($result!=null)
		{
			$this->session->set_flashdata('delete-post', 'success!!!');
			redirect('admin-view-users');
		}

	}

}
public function deleteUser($id)
{
	$this->db->where('id', $id);
	$result=$this->db->delete('user');
	if($result!=null)
		{
			$this->session->set_flashdata('delete-user', 'success!!!');
			redirect('admin-view-users');
		}

}


}

?>