<?php
defined('BASEPATH') OR exit ('No direct script access allowed');

class Welcome_model extends CI_Model {

	public function getNumberOFPosts()
	{
		return   $this->db->where('added_by',$this->session->userdata('fname'))->get('post')->num_rows();
	}
	public function verifyUsername($id)
	{
		return $this->db->where('email',$id)->where('authorized',1)->get('user');
	}
	public function insertPost(){


		if($this->input->post('title')){
			$data =array(
				'title'=>$this->input->post('title'),				
				'date'=>$this->input->post('date'),
				'content'=>$this->input->post('content'),
				'description'=>$this->input->post('description'),
				'auther'=>$this->input->post('auther'),
				'datetime'=>date('Y-m-d H-i-sA'),
				'added_by'=>$this->session->userdata('fname'),
			);
			$result=$this->db->insert('post',$data);
			if($result!=null)
			{
				$this->session->set_flashdata('add-post', 'success!!!');
				redirect('view-post');
			}
			
		}
	}
	public function getPost(){
		$query = $this->db->order_by('datetime',"desc")->get('post');
		if ($query) {
			return $query->result();
		}
	}
	 public function getPostsBySession($value='')
	{
		
		$query = $this->db->where('added_by',$this->session->userdata('fname'))->order_by('datetime',"desc")->get('post');
		if ($query) {
			return $query->result();
		}
		// code...
	}
	public function getPostDetails($id){
		$this->db->where('id',$id);
		$query = $this->db->get('post');
		if ($query) {
			return $query->row();
		}
	}
	public function updatePost($id){
		if($this->input->post('title')){
			$data =array(
				'title'=>$this->input->post('title'),				
				'date'=>$this->input->post('date'),
				'content'=>$this->input->post('content'),
				'description'=>$this->input->post('description'),
				'auther'=>$this->input->post('auther'),
				'added_by'=>$this->session->userdata('fname'),
                'datetime'=>date('Y-m-d H-i-sA'),
				'added_by'=>$this->session->userdata('fname'),
			);
			$this->db->where('id',$id);
			$result=$this->db->update('post',$data);
			if($result!=null)
			{
				$this->session->set_flashdata('update-post', 'success!!!');
				redirect('view-post');
			}
			
			redirect('view-post');
		}
	}
	public function deletePost($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('post');
		if($this->session->userdata('admin_username'))
		{
			redirect('admin-view-post');
		}
		else
		{
			redirect('view-post');
		}
	}
	public function getSinglePosts($id)
	{
		return $this->db->where('id',$id)->get('post')->row();
	}


	public function isUsernameExist($username)
	{
		return $this->db->where('email',$username)->get('user');
	}
	public function insertUser()
	{

		$username=$this->input->post('email');
		$check=$this->isUsernameExist($username);
		if($check->num_rows()>0)
		{
			$this->session->set_flashdata('signup-error', 'logout successfully');
			redirect('sign-up');       
		}
		else
		{
			if($this->input->post('fname')){
				$data =array(
					'first_name'=>$this->input->post('fname'),				
					'last_name'=>$this->input->post('lname'),
					'email'=>$this->input->post('email'),
					'password'=>$this->input->post('password'),
					'role'=>0,
					'authorized'=>0,
					'datetime'=>date('Y-m-d H-i-sA'),				
				);
			// print_r($data);exit();
				$data=$this->db->insert('user',$data);
				if($data!=null)
				{
					$this->session->set_flashdata('signup-success', 'logout successfully');
					redirect('sign-up');       
				}

			}

		}
	}
}

?>