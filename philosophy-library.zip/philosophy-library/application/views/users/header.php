<!DOCTYPE html>
<html>
<head>
  <title>DASHBOARD </title>
  <meta name="robots" content="noindex, nofollow">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2">
  <link href="<?php echo base_url()?>admin_assets/admin.css" rel="stylesheet">
  <link href="<?php echo base_url()?>assets/assets/dist/css/bootstrap.min.css" rel="stylesheet">

  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap4.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>

  <style>
   .help-block{
    color: red;
  }
</style>
</head>
<body>
  <!-- (B) NOW LOADING SPINNER -->
  <div id="page-loader">
    <img src="<?php echo base_url()?>admin_assets/cube-loader.svg"/>
  </div>
  <!-- (C) SIDE BAR -->
  <nav id="page-sidebar"style="max-width: 100% !important;">
    <a href="<?php echo base_url('user-dashboard')?>">
      DASHBOARD  
    </a>
    <a >
      <?php echo $this->session->userdata('fname')?> <?php echo $this->session->userdata('lname')?>
     </a>
  
    <a href="<?php echo base_url('view-post')?>">
      <span class="ico">&#9880;</span> POSTS
    </a>
     <a href="<?php echo base_url('')?>">
      <span class="ico">&#9880;</span>HOME PAGE
    </a>
      <a href="<?php echo base_url('logout')?>">
      <span class="ico">&#9880;</span> LOGOUT
    </a>
     <!--  <a href="pageB.php">
        <span class="ico">&#9880;</span> RESOLVE
      </a> -->
    </nav>