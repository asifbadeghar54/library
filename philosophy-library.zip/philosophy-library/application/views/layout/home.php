<!DOCTYPE html>

<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="description" content="PHILOSOPHY LIBRARY" />
  <meta name="author" content="PHILOSOPHY LIBRARY" />
  <meta name="generator" content="PHILOSOPHY LIBRARY" />
  <title>PHILOSOPHY LIBRARY</title>
  <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/headers/" />
  <!-- Bootstrap core CSS -->
  <link href="<?php echo base_url()?>assets/assets/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous" />
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <style>
    .bd-placeholder-img {
      font-size: 1.125rem;

      text-anchor: middle;

      -webkit-user-select: none;

      -moz-user-select: none;

      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
    .hero {
      background-image: url("<?php echo base_url()?>assets/images/nv.jpg");

      background-position: center;

      background-repeat: no-repeat;

      background-size: cover;

      background-attachment: fixed;

      height: 60vh;

      color: white;
    }

    .footer {
      position: fixed;

      left: 0;

      bottom: 0;

      width: 100%;

      padding: 10px;

      background-color: #333747;

      color: white;
    }
  </style>
  <!-- Custom styles for this template -->

  <link href="headers.css" rel="stylesheet" />
</head>
<body>
  <main class="container-fluid" style="background-color: lightgreen;">
    <!-- NavBar Start From here -->
    <div class="hero mb-2">
      <nav class="navbar navbar-expand-lg text-white">
        <a class="navbar-brand text-white" href="<?php echo base_url()?>">Philosophy Library</a>
        <i class="navbar-toggler far fa-bars text-white" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"></i>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto form-inline">
            <li class="nav-item active">
              <a class="nav-link text-white" href="<?php echo base_url()?>">
                <button class="btn btn-light">Home</button>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="<?php echo base_url('login')?>">
                <button class="btn btn-light">Login</button>
              </a>
            </li>
          </ul>
        </div>
      </nav>
    </div>
  <!-- NavBar End From here -->
   <!-- Blog Lists -->
      <div class="row mb-4">
        <?php foreach($post_details as $post): ?>
          <div class="col-lg-12 text-white">
            <div class="card bg-success mb-4" style="margin-bottom: 10px;">
              <div class="card-body">
                <h4 class="card-title text-white">
                  <a class="text-white" href="<?php echo base_url('single-post/'.$post->id)?>"><?php echo $post->title; ?> </a>
                </h4>
                <ul class="navbar-nav">
                  <li><?php echo $post->auther; ?></li>
                  <li><?php echo $post->content; ?></li>
                  <li><?php echo substr($post->description, 0, 100) ?></li>
                  <li><?php echo $post->date; ?></li>
                  <li>
                    Last Updated By :
                    <?php echo $post->added_by; ?>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
         <!-- Blog Lists -->
  </main>
  <footer class="footer-area footer">
    <div class="container">
      <div class="row">
        <div class="text-center">
          <span class="">Copyright © 2021 Philosophy Library</span>
        </div>
      </div>
    </div>
  </footer>
</body>
<script src="<?php echo base_url()?>assets/assets/dist/js/bootstrap.bundle.min.js"></script>
</html>
