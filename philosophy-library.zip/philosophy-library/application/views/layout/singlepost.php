<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="description" content="PHILOSOPHY LIBRARY" />
  <meta name="author" content="PHILOSOPHY LIBRARY" />
  <meta name="generator" content="PHILOSOPHY LIBRARY" />
  <title>PHILOSOPHY LIBRARY</title>
  <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/headers/" />
  <!-- Bootstrap core CSS -->
  <link href="<?php echo base_url()?>assets/assets/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous" />
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <style>
      body, html {
        height: 100%;
        margin: 0;
        background-color: lightgreen;
      }

      .bg {
        /* The image used */
        background-image: url("img_girl.jpg");

        /* Full height */
        height: 100%; 

        /* Center and scale the image nicely */
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
      }
      .hero{
        background-image: url("<?php echo base_url()?>assets/images/nv.jpg");
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        background-attachment: fixed;
        height: 40vh;
        color: white;
      }
      .footer {
       position: fixed;
       left: 0;
       bottom: 0;
       width: 100%;
       padding: 10px;
       background-color: #333747;
       color: white;

     }
   </style>
   <!-- Custom styles for this template -->
   <link href="headers.css" rel="stylesheet">
 </head>
 <body>
  <main class="container-fluid"style="background-color: lightgreen;">
    <div class="hero mb-2">
       <nav class="navbar navbar-expand-lg text-white">
        <a class="navbar-brand text-white" href="<?php echo base_url()?>">Philosophy Library</a>
        <i class="navbar-toggler far fa-bars text-white" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"></i>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto form-inline">
            <li class="nav-item active">
              <a class="nav-link text-white" href="<?php echo base_url()?>">
                <button class="btn btn-light">Home</button>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="<?php echo base_url('login')?>">
                <button class="btn btn-light">Login</button>
              </a>
            </li>
          </ul>
        </div>
      </nav>
   </div>
   
   <div class="row mb-4">
     <div class="col-lg-12 text-white">
      <div class="card bg-success  mb-4" style="margin-bottom: 10px">
        <div class="card-body">
          <h5 class="card-title"><?php if($eachPost->added_by!=null) echo $eachPost->title; ?></h5>
          
          <ul class="navbar-nav">
            <li><?php if($eachPost->auther!=null) echo $eachPost->auther; ?></li>
            <li><?php if($eachPost->content!=null)echo $eachPost->content; ?></li>
            <li><?php if($eachPost->description!=null)echo $eachPost->description?></li>
            <li><?php if($eachPost->date!=null) echo $eachPost->date; ?></li>
            <li>Last Updated By : <?php if($eachPost->added_by!=null) echo $eachPost->added_by; ?></li>
          </ul>
        </div>   
      </div>
    </div>
  </div>
  
</main>

<footer class="footer-area footer" >
  <div class="container ">
    <div class="row ">
      <div class="text-center">
       <span class="">Copyright © 2021 Philosophy Library</span>
     </div>

   </div>
 </div>
</footer>
</body>
<script src="<?php echo base_url()?>assets/assets/dist/js/bootstrap.bundle.min.js"></script>
</html>
