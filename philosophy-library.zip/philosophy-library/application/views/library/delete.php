<?php
    include_once("functions.php");
    
    $dbconnect = dblink();

    if ($dbconnect) {
        echo "<!-- Established Connection -->";

    }
    //ShowMEM();


    $id = $_GET['id'];

    deleteuser($dbconnect,$id);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <hr>
    <a href="index.php">Return Home</a>

    
</body>
</html>