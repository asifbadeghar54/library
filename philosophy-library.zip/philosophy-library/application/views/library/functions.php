<?php

function dblink()  {
    $dbUser = "Nestor";
    $dbpass = "YES";
    $dbhost = "localhost";
    $db = "nestordbs";


$mysqli = new mysqli($dbhost,$dbUser,$dbpass,$db);

    if ($mysqli->connect_errno) {
        echo 'failed to connect'; 
        $mysqli->connect_errno;
        exit ();
     }

     return $mysqli;

}

    function insertuser($dbConnect,$fname,$lname,$username,$pwd) {
        $sql = "INSERT INTO users (id,firstname,lastname,username,password) VALUES (NULL,'$fname','$lname','$username','$pwd')";
        if ($dbConnect->query($sql) == true) {
            echo 'Record Added';
        } 
        else {
            echo 'Error: '.$sql.'<br>'.$dbConnect->error;
        }
}



function showMem() {
    echo "<pre>";
    echo "<h4><GET</h4>";
    print_r($_GET);
    echo "<h4><POST</h4>";
    print_r($_POST);
    echo "<h4><SESSION</h4>";
    print_r($_SESSION);
    echo "</pre>";
}

function listUsers($dbConnect) {
    $sql = "SELECT * FROM users";
    $result = mysqli_query($dbConnect, $sql);
    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            echo 'Name: '.$row['firstname'].' '.$row['lastname'].' || username: '.$row['username'].' || Password: '.$row['password'].' || <a href="edit.php?id='.$row['id'].'">
            [Edit]</a> || <a href="delete.php?id='.$row['id'].'">[Delete]</a><br>';
        }
    }


}

function updateuser($dbconnect,$id,$fname,$lname,$uname,$pwd) {
    $sql = "UPDATE users SET firstname = '$fname', lastname = '$lname', username = '$uname', password = '$pwd' WHERE id = '$id'";
    if (mysqli_query($dbconnect,$sql)) {
        echo 'Record Updated';
    } 
    else {
        echo'Error:'.$sql.'<br>'.$dbconnect->error;
    }
}

function    deleteuser($dbconnect,$id) {
    $sql = "DELETE FROM users WHERE id='$id'";
    if (mysqli_query($dbconnect,$sql)) {
        echo 'Record Deleted';
    } 
    else {
        echo'Error:'.$sql.'<br>'.$dbconnect->error;
    }
}





?>