<!doctype html>

    <html lang="en">

    <head>

        <meta charset="utf-8">

        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="PHILOSOPHY LIBRARY">

        <meta name="author" content="PHILOSOPHY LIBRARY">

        <meta name="generator" content="PHILOSOPHY LIBRARY">

      <title>PHILOSOPHY LIBRARY</title>



        <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/headers/">

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>





        <!-- Bootstrap core CSS -->

        <link href="<?php echo base_url()?>assets/assets/dist/css/bootstrap.min.css" rel="stylesheet">

 <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>

 <style>

   .help-block{

    color: red;

   }

 </style>

        <style>

          .bd-placeholder-img {

            font-size: 1.125rem;

            text-anchor: middle;

            -webkit-user-select: none;

            -moz-user-select: none;

            user-select: none;

        }



        @media (min-width: 768px) {

            .bd-placeholder-img-lg {

              font-size: 3.5rem;

          }

      }

      .centerText {

        display: flex;

        justify-content: center;

    }

</style>

<!-- Custom styles for this template -->

<link href="headers.css" rel="stylesheet">

</head>

<body>

<?php  $message=$this->session->flashdata('signup-success')?>

  <?php    if (isset($message)) {?>

     <div class="alert alert-success alert-dismissible fade show" role="alert">

  <strong>  Thanks for registering.</strong>You need authorization from the admin to start posting.

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">

    <span aria-hidden="true">&times;</span>

  </button>

</div>

<?php }?>

<?php  $message=$this->session->flashdata('signup-error')?>

  <?php    if (isset($message)) {?>

     <div class="alert alert-danger alert-dismissible fade show" role="alert">

  <strong>Username already Exist .</strong>

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">

    <span aria-hidden="true">&times;</span>

  </button>

</div>

<?php }?>

    <div class="container-fluid centerText"style="margin-top:50px;margin-bottom:50px;">

    

        <div class="card ">  

         <div class="card-body ">

            <h2 class="text-center">Sign Up</h2>

            <p class="text-center">Please fill in your credentials</p>

           <form  method="post" id="addPost" name="addPost" action="<?php echo base_url('insert-user')?>">

               <div class="row ">

                 <div class="col-lg-6 col-md-6 col-sm-12 ">

                    <div class="form-group ">

                        <label>First Name</label>

                        <input type="text" name="fname"  class="form-control " placeholder="first name">

                        <span class="invalid-feedback"></span>

                    </div>

                </div>  

                    <div class="col-lg-6 col-md-6 col-sm-12">

                        <div class="form-group">

                            <label>Last Name</label>

                            <input type="text" name="lname"  class="form-control " placeholder="last name">

                            <span class="invalid-feedback"></span>

                        </div>

                    </div>

                    <div class="col-lg-6 col-md-6 col-sm-12">

                        <div class="form-group">

                            <label>Username</label>

                            <input type="text" name="email"  class="form-control " placeholder="user name">

                            <span class="invalid-feedback"></span>

                        </div>

                    </div>

                    <div class="col-lg-6 col-md-6 col-sm-12">

                        <div class="form-group">

                            <label>Password</label>

                            <input type="text" name="password" class="form-control "placeholder="password">

                            <span class="invalid-feedback"></span>

                        </div>

                    </div>

                      <div class="col-lg-6 col-md-6 col-sm-12">

                        <div class="form-group">

                            <label>Confirm Password</label>

                            <input type="text" name="confirm_password" class="form-control "placeholder="password">

                            <span class="invalid-feedback"></span>

                        </div>

                    </div>

                    <div class="form-group mt-3">

                        <input type="submit" class="btn btn-primary" value="submit">

                    </div>

                    <p>Already  have an account? <a href="<?php echo base_url('login')?>">Login</a>.</p>

                     <p><a href="<?php echo base_url('')?>">Home Page</a></p>

                </div> </div>

                <!-- <p>Don't have an account? <a href="register.php">Sign up now</a>.</p> -->

            </form>



        </div>

    </div>

</div>

<script src="<?php echo base_url()?>assets/assets/dist/js/bootstrap.bundle.min.js"></script>



<script type="text/javascript" src="//cdn.jsdelivr.net/jquery.bootstrapvalidator/0.5.0/js/bootstrapValidator.min.js"></script>

<script>

$(".alert").alert('close')</script>

<script>

    $(document).ready(function() {

        $('#addPost').bootstrapValidator({

            

            feedbackIcons: {

                valid: 'glyphicon glyphicon-ok',

                invalid: 'glyphicon glyphicon-remove',

                validating: 'glyphicon glyphicon-refresh'

            },

            fields: {

                fname: {

                    message: 'The Meal type is not valid',

                    validators: {

                        notEmpty: {

                            message: 'Please enter First Name'

                        },

                        

                    }

                },

                lname: {

                    message: 'The Meal type is not valid',

                    validators: {

                        notEmpty: {

                            message: 'Please Enter Last Name'

                        },

                        

                    }

                },

                email: {

                    message: 'The Meal type is not valid',

                    validators: {

                        notEmpty: {

                            message: 'Please Enter Email'

                        },

                        

                    }

                },

                password: {

                    message: 'The Meal type is not valid',

                    validators: {

                        notEmpty: {

                            message: 'Please Enter Password'

                        },

                        

                    }

                },

                confirm_password: {

                validators: {

                    notEmpty: {

                        message: 'Password is required and cannot be empty'

                    },

                    identical: {

                        field: 'password',

                        message: 'password is not matching'

                    }

                }



            }

                

            }

        });

    });

</script>

</body>

</html>