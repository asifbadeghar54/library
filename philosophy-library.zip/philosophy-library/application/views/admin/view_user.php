<!-- (D) MAIN CONTENTS -->

<div id="page-main">
    <!-- (D1) NAVIGATION BAR -->

    <nav id="page-nav" style="padding-top: 5px;">
        <div id="page-button-side" onclick="admin.sidebar();">&#9776;</div>

        <!-- <div id="page-button-out" onclick="admin.bye();">&#9747;</div> -->

        <h3 class="text-center">VIEW USERS</h3>
    </nav>

    <!-- (D2) PAGE CONTENTS -->

    <main id="page-contents">
        <?php  $message=$this->session->flashdata('user-authorize')?>

        <?php    if (isset($message)) {?>

        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong> User Authorized successfully.</strong>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>

        <?php }?>

        <?php  $message2=$this->session->flashdata('update-user')?>

        <?php    if (isset($message2)) {?>

        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong> Post Updated successfully.</strong>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>

        <?php }?>

        <?php  $message3=$this->session->flashdata('delete-user')?>

        <?php    if (isset($message3)) {?>

        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>User Deleted successfully.</strong>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php }?>
        <?php 
                    if(isset($_SESSION['user-authorize'])){
                            unset($_SESSION['user-authorize']);
                        }
                        if(isset($_SESSION['update-user'])){
                            unset($_SESSION['update-user']);
                        }
                        if(isset($_SESSION['delete-user'])){
                            unset($_SESSION['delete-user']);
                        }

                    ?>
        <!--  <div style="margin: 20px">

   

       </div> -->

        <div class="table-responsive" style="justify-content: center;">
            <table id="example" class="table table-striped table-bordered" style="width: 100%;">
                <!--  <a href="<?php echo base_url('admin-add-user')?>">

          <button type="button" class="btn btn-primary btn-sm" style="float: right;">Add Post</button> 

        </a> -->

                <thead>
                    <tr>
                        <th>Sl.No</th>

                        <th>First Name</th>

                        <th>Last Name</th>

                        <th>Username</th>

                        <th>Password</th>

                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $i=1;

        foreach($user_details as $user): ?>

                    <tr>
                        <td><?php echo $i; ?></td>

                        <td><?php echo $user->first_name; ?></td>

                        <td><?php echo $user->last_name; ?></td>

                        <td><?php echo $user->email; ?></td>

                        <td><?php echo $user->password; ?></td>

                        <td>
                            <!--  <a href="<?php echo base_url('admin-edit-user/'.$user->id)?>" style="padding: 10px"><button class="btn btn-primary btn-sm">Edit</button></a> -->

                            <a href="<?php echo base_url('admin-delete-user/'.$user->id)?>"><button class="btn btn-danger btn-sm">Delete</button></a>

                            <?php if ($user->authorized==1) {?>

                            <button class="btn btn-success btn-sm">user is authorized</button>

                            <?php }else{?>

                            <a href="<?php echo base_url('authorize-user/'.$user->id)?>">
                                <button class="btn btn-primary btn-sm">Authroize this user</button>

                                <?php }?>
                            </a>
                        </td>
                    </tr>

                    <?php $i++; endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- <h2>DASHBOARD</h2> -->
    </main>
</div>
