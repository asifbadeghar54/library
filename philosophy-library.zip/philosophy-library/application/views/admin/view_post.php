<!-- (D) MAIN CONTENTS -->

<div id="page-main">
    <!-- (D1) NAVIGATION BAR -->

    <nav id="page-nav" style="padding-top: 5px;">
        <div id="page-button-side" onclick="admin.sidebar();">&#9776;</div>

        <!-- <div id="page-button-out" onclick="admin.bye();">&#9747;</div> -->

        <h3 class="text-center">VIEW POST</h3>
    </nav>

    <!-- (D2) PAGE CONTENTS -->

    <main id="page-contents">
        <?php  $message=$this->session->flashdata('add-post')?>

        <?php    if (isset($message)) {?>

        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong> Post Added successfully.</strong>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>

        <?php }?>

        <?php  $message2=$this->session->flashdata('update-post')?>

        <?php    if (isset($message2)) {?>

        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong> Post Updated successfully.</strong>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>

        <?php }?>

        <?php  $message3=$this->session->flashdata('delete-post')?>

        <?php    if (isset($message3)) {?>

        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong> Post Deleted successfully.</strong>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>

        <?php }?>

        <!--  <div style="margin: 20px">

<?php 

                    if(isset($_SESSION['add-post'])){
                            unset($_SESSION['add-post']);
                        }
                        if(isset($_SESSION['update-post'])){
                            unset($_SESSION['update-post']);
                        }
                        if(isset($_SESSION['delete-post'])){
                            unset($_SESSION['delete-post']);
                        }

                    ?>

       </div> -->

        <div class="container-fluid">
            <div class="table-responsive w-100">
                <table id="example" class="table table-striped table-bordered" style="width: 100%;">
                    <a href="<?php echo base_url('admin-add-post')?>">
                        <button type="button" class="btn btn-primary btn-sm ml-2" style="float: right;">Add Post</button>
                    </a>

                    <thead>
                        <tr>
                            <th width="15%">Auther</th>

                            <th width="15%">Title</th>

                            <th width="15%">Content</th>

                            <th width="40%">Description</th>

                            <th width="15%">Date</th>

                            <th width="15%">Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $i=1;

          foreach($post_details as $post): ?>

                        <tr>
                            <td><?php echo $post->auther; ?></td>

                            <td><?php echo $post->title; ?></td>

                            <td><?php echo $post->content; ?></td>

                            <td><?php echo $post->description; ?></td>

                            <td><?php echo $post->date; ?></td>

                            <td>
                                <a href="<?php echo base_url('admin-edit-post/'.$post->id)?>"><button class="btn btn-primary btn-sm" style="margin: 5px;">Edit</button></a>

                                <?php if($this->session->userdata('admin_username')){?>

                                <a href="<?php echo base_url('admin-delete-post/'.$post->id)?>"><button class="btn btn-danger btn-sm">Delete</button></a>
                                <?php }?>
                            </td>
                        </tr>

                        <?php $i++; endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- <h2>DASHBOARD</h2> -->
    </main>
</div>
