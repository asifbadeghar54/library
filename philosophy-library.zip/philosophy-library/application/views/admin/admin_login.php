<!doctype html>

<html lang="en">

  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="PHILOSOPHY LIBRARY" />
    <meta name="author" content="PHILOSOPHY LIBRARY" />
    <meta name="generator" content="PHILOSOPHY LIBRARY" />
    <title>PHILOSOPHY LIBRARY</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/headers/" />
    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url()?>assets/assets/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
    <link href="headers.css" rel="stylesheet" />

<style>
    .help-block {
        color: red;
    }
</style>
<style>
    .bd-placeholder-img {
        font-size: 1.125rem;

        text-anchor: middle;

        -webkit-user-select: none;

        -moz-user-select: none;

        user-select: none;
    }
    @media (min-width: 768px) {
        .bd-placeholder-img-lg {
            font-size: 3.5rem;
        }
    }
    .centerText {
        display: flex;

        justify-content: center;
    }
</style>
    <!-- Custom styles for this template -->
  </head>
<body>
<div class="container-fluid centerText" style="margin-top: 50px; margin-bottom: 50px;">
    <div class="card">
        <div class="card-body">
            <?php  $message1=$this->session->flashdata('incorrect-password-error')?>
            <?php    if (isset($message1)) {?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Wrong Password.</strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php }?>
            <?php  $message2=$this->session->flashdata('no-account-found-error')?>
            <?php    if (isset($message2)) {?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>No Account Found.</strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php }?>
            <?php 
                    if(isset($_SESSION['no-account-found-error'])){
                            unset($_SESSION['no-account-found-error']);
                        }
                        if(isset($_SESSION['incorrect-password-error'])){
                            unset($_SESSION['incorrect-password-error']);
                        }

                    ?>
            <h2 class="text-center">Login</h2>
            <p class="text-center">Please fill in your credentials to login.</p>
            <form class="" id="addPost" action="<?php echo base_url('verify-admin-login')?>" method="post">
                <div class="row centerText">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="form-group">
                            <label class="">Username</label>

                            <input type="text" name="username" class="form-control" value="" />

                            <span class="invalid-feedback"></span>
                        </div>
                    </div>
                </div>
                <div class="row centerText">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control" />
                            <span class="invalid-feedback"></span>
                        </div>
                    </div>
                </div>
                <div class="form-group mt-3">
                    <input type="submit" class="btn btn-primary" value="Login" />
                </div>
                <p class="text-center"><a href="<?php echo base_url('')?>">Home Page</a></p>
            </form>
        </div>
    </div>
</div>

<script src="<?php echo base_url()?>assets/assets/dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/jquery.bootstrapvalidator/0.5.0/js/bootstrapValidator.min.js"></script>
<script>
    $(document).ready(function () {
        $("#addPost").bootstrapValidator({
            feedbackIcons: {
                valid: "glyphicon glyphicon-ok",

                invalid: "glyphicon glyphicon-remove",

                validating: "glyphicon glyphicon-refresh",
            },

            fields: {
                username: {
                    validators: {
                        notEmpty: {
                            message: "username is required",
                        },
                    },
                },
                password: {
                    message: "The Meal type is not valid",

                    validators: {
                        notEmpty: {
                            message: "password is required",
                        },
                    },
                },
            },
        });
    });
</script>
  </body>
</html>

