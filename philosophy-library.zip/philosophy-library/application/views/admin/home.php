<!-- (D) MAIN CONTENTS -->
<div class="" id="page-main">
    <!-- (D1) NAVIGATION BAR -->
    <nav id="page-nav" style="padding-top: 5px;">
        <div id="page-button-side" onclick="admin.sidebar();">&#9776;</div>
        <div class="">
            <h3 class="text-center">HOME</h3>
        </div>
    </nav>
    <!-- (D2) PAGE CONTENTS -->

    <div class="container-fluid">
        <div class="row">
            <div class="card" style="width: 18rem; margin: 5px;">
                <div class="card-body">
                    <h5 class="card-title">
                        Total Blogs :
                        <?php echo $total ?>
                    </h5>
                </div>
            </div>
            <div class="card" style="width: 18rem; margin: 5px;">
                <div class="card-body">
                    <h5 class="card-title">
                        Total Users :
                        <?php echo $totalUser ?>
                    </h5>
                </div>
            </div>
        </div>
        <div class="card-body text-center">
            <a href="<?php echo base_url()?>"> <button>Home Page</button></a>
        </div>
    </div>
</div>
