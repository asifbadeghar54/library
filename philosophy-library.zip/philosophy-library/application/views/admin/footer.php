<script src="<?php echo base_url()?>admin_assets/admin.js"></script>
<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap4.min.js"></script>
<script>
    $(document).ready(function () {
        $("#example").DataTable();
    });
</script>
</body>
</html>