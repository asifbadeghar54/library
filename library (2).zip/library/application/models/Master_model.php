<?php

if (!defined('BASEPATH')) {
   exit('No direct script access allowed');
}

class Master_model extends CI_Model {

 public function addProjectsData() {
   $pId=$this->Members_model->generateRandomString(6);
    $data=array(
      'project_id'=>$pId,
      'project_name'=>$this->input->post('project_name'),
      'short_code'=>     $this->input->post('short_code'),
      'project_status'=>$this->input->post('project_status')
   );
   // print_r($data);exit; 
    $this->db->insert('projects',$data);
    redirect('addprojects');
 }
 public function deleteProjectsData(){
   $this->db->where('id',$this->input->post('did'));
   $this->db->delete('projects');
          // print_r($this->db->last_query());exit;
   $this->session->set_flashdata("deletesuccess","Deleted successfully.");
   redirect('addprojects');
}
public function updateProjectsData() {
   $id=$this->input->post('pr_id');
   $data=array(
      'project_name'=>$this->input->post('project_name'),
      'short_code'=>     $this->input->post('short_code'),
      'project_status'=>$this->input->post('project_status')
   );
   // print_r($data);exit; 
   $this->db->set($data)->where('id',$id)->update('projects');
   redirect('addprojects');
}

// Employee Section
public function addEmployeeData() {
 $data=array(
   'employee_id'       =>$this->input->post('employee_id'),
   'employee_name'     =>$this->input->post('employee_name'),
   'employee_type'     =>$this->input->post('employee_type'),
   'mobile_no'         =>$this->input->post('mobile_no'),
   'employee_email'    =>$this->input->post('employee_email'),
   'employee_photo'    =>"Photo",
);
   // print_r($data);exit; 
 $this->db->insert('employee',$data);
 redirect('viewemployee');
}
public function deleteEmployeeData(){
   $this->db->where('id',$this->input->post('did'));
   $this->db->delete('employee');
          // print_r($this->db->last_query());exit;
   $this->session->set_flashdata("deletesuccess","Deleted successfully.");
   redirect('viewemployee');
}

public function updateemployeedata() {
   $id=$this->input->post('emp_id');
   $data=array(
      'employee_id'       =>$this->input->post('employee_id'),
      'employee_name'     =>$this->input->post('employee_name'),
      'employee_type'     =>$this->input->post('employee_type'),
      'mobile_no'         =>$this->input->post('mobile_no'),
      'employee_email'    =>$this->input->post('employee_email'),
      'employee_photo'    =>"Photo",
   );
   // print_r($data);exit; 
   $this->db->set($data)->where('id',$id)->update('employee');
   redirect('viewemployee');
}
public function getAllProjects()
{
   return $this->db->get('projects')->result();
}
public function getEachProjects($id)
{
   return $this->db->select('*')->from('projects')->where('id',$id)->get()->row();
}
public function getAllEmployee()
{
   return $this->db->get('employee')->result();
}
public function eachEmployee($id)
{
  return $this->db->select('*')->from('employee')->where('id',$id)->get()->row();
}
public function getAllEmployeeType()
{
   return $this->db->get('employee_type')->result();
}
/* Employee Section END*/

/*New Plot Section*/
public function addNewPlotData() {
$plotSizeID=$this->Members_model->generateRandomString(6);
 $data=array(
   'psize_id'=>$plotSizeID,
   'length'       =>$this->input->post('length'),
   'breadth'     =>$this->input->post('breadth'),
);
   // print_r($data);exit; 
 $this->db->insert('plot_size',$data);
 redirect('addnewplots');
}
public function deleteNewPlotData(){
   $this->db->where('id',$this->input->post('did'));
   $this->db->delete('plot_size');
          // print_r($this->db->last_query());exit;
   $this->session->set_flashdata("deletesuccess","Deleted successfully.");
   redirect('addnewplots');
}
public function editNewPlotData() {
   $id=$this->input->post('plot_id');
   $data=array(
      'length'       =>$this->input->post('length'),
      'breadth'     =>$this->input->post('breadth'),
   );
   // print_r($data);exit; 
   $this->db->set($data)->where('id',$id)->update('plot_size');
   redirect('addnewplots');
}
public function eachPlotSize($id)
{
   return $this->db->select('*')->from('plot_size')->where('id',$id)->get()->row();
}
public function getNewPlotSize()
{
   return $this->db->get('plot_size')->result();
}
/*New Land Section*/
public function addNewLandData() {
 $data=array(
   'project_name'  =>$this->input->post('project_name'),
   'plot_length_breadth'  =>$this->input->post('plot_length_breadth'),
   'amount'        =>$this->input->post('plot_amount'),
);
   // print_r($data);exit; 
 $this->db->insert('land_details',$data);
 redirect('addlanddetails');
}
public function deleteNewLandData(){
   $this->db->where('id',$this->input->post('did'));
   $this->db->delete('land_details');
          // print_r($this->db->last_query());exit;
   $this->session->set_flashdata("deletesuccess","Deleted successfully.");
   redirect('addlanddetails');
}
public function editNewLandData() {
   $id=$this->input->post('land_id');
   $data=array(
      'project_name'  =>$this->input->post('project_name'),
      'plot_length_breadth'  =>$this->input->post('plot_length_breadth'),
      'amount'        =>$this->input->post('plot_amount'),
   );
   // print_r($data);exit; 
   $this->db->set($data)->where('id',$id)->update('land_details');
   redirect('addlanddetails');
}
public function getNewLandData()
{
  return $this->db->join('plot_size','plot_size.psize_id=land_details.plot_length_breadth')->get('land_details')->result();
}
public function getEachLandDetails($id)
{
  return $this->db->select('*')->from('land_details')->where('id',$id)->get()->row();
}
/**/
public function addProjectStatusData()
{
   $data=array(
      'project_name'  =>$this->input->post('project_name'),
      'status_title'  =>$this->input->post('status_title'),
      'status_date'        =>$this->input->post('status_date'),
      'status_details'        =>$this->input->post('status_details'),
    // 'file_image'        =>'file',
      'notifi_vi_sms' =>$this->input->post('notifi_vi_sms'),
      'notifi_vi_email' =>$this->input->post('notifi_vi_email'),
   );
   // print_r($data);exit; 
   $this->db->insert('project_status',$data);
   redirect('addprojectstatus');
}
public function getProjectStatusData()
{
   return $this->db->get('project_status')->result();
}


/**/
public function insertReminder() {
  $r_id=$this->Setting_model->generateRandomString(6);
  $data=array(
    'reminder_id'=>$r_id,
    'reminder_title'=>$this->input->post('reminder_title'),
    'reminder_description'=>$this->input->post('reminder_description'),
    'reminder_date'=>$this->input->post('reminder_date'),
    'reminder_repeat'=>$this->input->post('reminder_repeat'),
    'reminder_end_date'=>$this->input->post('reminder_end_date'),
    'updated_date'=>date('Y-m-d H:i:s'),
 );
   // print_r($data);exit; 
  $this->db->insert('reminder',$data);
  redirect('viewreminder');
}
public function deleteReminder($id){
   $this->db->where('reminder_id',$this->input->post('did'));
   $this->db->delete('reminder');
   $this->session->set_flashdata("deletesuccess","Deleted successfully.");
   redirect('viewreminder');
}
public function editReminder($id) {
   $data=array(
    'reminder_title'=>$this->input->post('reminder_title'),
    'reminder_description'=>$this->input->post('reminder_description'),
    'reminder_date'=>$this->input->post('reminder_date'),
    'reminder_repeat'=>$this->input->post('reminder_repeat'),
    'reminder_end_date'=>$this->input->post('reminder_end_edate'),
    'updated_date'=>date('Y-m-d H:i:s'),
 );
   // print_r($data);exit; 
   $this->db->set($data)->where('reminder_id',$id)->update('reminder');
   redirect('viewreminder');
}
public function getAllReminders()
{
  return $this->db->get('reminder')->result();
}

/**/
public function insertContactMembers() {
  $r_id=$this->Setting_model->generateRandomString(6);
  $data=array(
    'cm_id'=>$r_id,
    'contact_type'=>$this->input->post('contacts'),
    'member_name'=>$this->input->post('member_name'),
    'member_email'=>$this->input->post('member_email'),
    'file'=>$this->input->post('message'),
    'message'=>$this->input->post('message'),
    'updated_date'=>date('Y-m-d H:i:s'),
 );
   // print_r($data);exit; 
  $this->db->insert('contact_members',$data);
  redirect('addreminder');
}
public function deleteContactMembers($id){
   $this->db->where('cm_id',$this->input->post('did'));
   $this->db->delete('contact_members');
   $this->session->set_flashdata("deletesuccess","Deleted successfully.");
   redirect('addreminder');
}

public function reports($id) {
   
   $data=array(
    'reminder_title'=>$this->input->post('reminder_title'),
    'reminder_description'=>$this->input->post('reminder_description'),
    'reminder_date'=>$this->input->post('reminder_date'),
    'reminder_repeat'=>$this->input->post('reminder_repeat'),
    'reminder_end_date'=>$this->input->post('reminder_end_date'),
    'updated_date'=>date('Y-m-d H:i:s'),
 );
   // print_r($data);exit; 
   $this->db->set($data)->where('reminder_id',$id)->update('reminder');
   redirect('addreminder');
}


}?>