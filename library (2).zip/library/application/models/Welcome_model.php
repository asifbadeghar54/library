<?php
defined('BASEPATH') OR exit ('No direct script access allowed');

class Welcome_model extends CI_Model {

	public function insertPost(){
		if($this->input->post('title')){
			$data =array(
				'title'=>$this->input->post('title'),				
				'date'=>$this->input->post('date'),
				'content'=>$this->input->post('content'),
				'description'=>$this->input->post('description'),
				'auther'=>$this->input->post('auther'),
				'datetime'=>date('Y-m-d H-i-sA'),
			);
			$this->db->insert('post',$data);
			redirect('view-post');
		}
	}
	public function getPost(){

		$query = $this->db->order_by('datetime',"desc")->get('post');
		if ($query) {
			return $query->result();
		}
	}
	public function getPostDetails($id){
		$this->db->where('id',$id);
		$query = $this->db->get('post');
		if ($query) {
			return $query->row();
		}
	}
	public function verifyUsername($id)
	{
		return $this->db->where('email',$id)->where('authorized',1)->get('user');
	}
	public function verifyAdminLogin($id)
	{
		return $this->db->where('email',$id)->get('admin');
	}
	public function updatePost($id){
		if($this->input->post('title')){
			$data =array(
				'title'=>$this->input->post('title'),				
				'date'=>$this->input->post('date'),
				'content'=>$this->input->post('content'),
				'description'=>$this->input->post('description'),
				'auther'=>$this->input->post('auther'),

			);
			$this->db->where('id',$id);
			$this->db->update('post',$data);
			redirect('view-post');
		}
	}
	public function deletePost($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('post');
		redirect('view-post');
	}
	public function authorizeUser($id)
	{
		$this->db->set('authorized',1)->where('id', $id);
		$this->db->update('user');
		redirect('view-users');
	}
    //Users

	public function insertUser(){
		if($this->input->post('fname')){
			$data =array(
				'first_name'=>$this->input->post('fname'),				
				'last_name'=>$this->input->post('lname'),
				'email'=>$this->input->post('email'),
				'password'=>$this->input->post('password'),
				'role'=>0,
				'authorized'=>0,
				'datetime'=>date('Y-m-d H-i-sA'),				
			);
			// print_r($data);exit();
			$this->db->insert('user',$data);
			redirect('sign-up');
		}
	}
	public function getUser(){

		$query = $this->db->where('role',0)->get('user');
		if ($query) {
			return $query->result();
		}
	}
	public function getUserDetail($id){
		$this->db->where('id',$id);
		$query = $this->db->order_by('datetime','desc')->get('user');
		if ($query) {
			return $query->row();
		}
	}
	public function updateUser($id){

		if($this->input->post('fname')){
			
			$data =array(
				'first_name'=>$this->input->post('fname'),				
				'last_name'=>$this->input->post('lname'),
				'email'=>$this->input->post('email'),
				'password'=>$this->input->post('password')				
			);
			$this->db->where('id',$id);
			$this->db->update('user',$data);
			redirect('view-users');
		}
	}
	public function deleteUser($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('user');
		redirect('view-users');
	}

}
?>