<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

/**
* Index Page for this controller.
*
* Maps to the following URL
* http://example.com/index.php/welcome
* - or -
* http://example.com/index.php/welcome/index
* - or -
* Since this controller is set as the default controller in
* config/routes.php, it's displayed at http://example.com/
*
* So any other public methods not prefixed with an underscore will
* map to /index.php/welcome/<method_name>
* @see https://codeigniter.com/user_guide/general/urls.html
*/
// public function index()
// {
// $this->load->view('welcome_message');
// }

public function index()
{
	 // $this->load->view('layout/header');
	$data['post_details'] = $this->Welcome_model->getPost();
	$this->load->view('layout/home',$data);
	 // $this->load->view('layout/footer');
}
public function login()
{
	$this->load->view('library/login');

}
public function adminLogin()
{
	$this->load->view('library/login');
}
public function verifyLogin() 
{

  $username = $this->input->post('username');
  $password = $this->input->post('password');
  // $remember=$this->input->post('rememberme');
  $login_user_details = $this->Welcome_model->verifyUsername($username);
  if ($login_user_details->num_rows() > 0) {
   $login_user_details = $login_user_details->row();
   if ($login_user_details->password == $password) {
    $_SESSION['username'] = $login_user_details->username;
    $_SESSION['role'] = $login_user_details->role;
    // $_SESSION['id'] = $login_user_details->id;
    $_SESSION['fname'] = $login_user_details->first_name;
     $_SESSION['lname'] = $login_user_details->last_name;
    $this->session->set_flashdata('login-success', 'login success...');
    redirect('admin-home');
  } else {
    $this->session->set_flashdata('incorrect-password-error', 'incorrect password!!!');
    redirect('login');
  }
} else {
 $this->session->set_flashdata('no-account-found-error', 'no account found with this username..');
 redirect('login');
}
}

public function verifyAdminLogin() 
{

  $username = $this->input->post('username');
  $password = $this->input->post('password');
  // $remember=$this->input->post('rememberme');
  $login_user_details = $this->Welcome_model->verifyAdminLogin($username);
  if ($login_user_details->num_rows() > 0) {
   $login_user_details = $login_user_details->row();
   if ($login_user_details->password == $password) {
    $_SESSION['username'] = $login_user_details->username;
    $_SESSION['role'] = $login_user_details->role;
    // $_SESSION['id'] = $login_user_details->id;
    // $_SESSION['name'] = $login_user_details->name;
    $this->session->set_flashdata('login-success', 'login success...');
    redirect('admin-home');
  } else {
    $this->session->set_flashdata('incorrect-password-error', 'incorrect password!!!');
    redirect('login');
  }
} else {
 $this->session->set_flashdata('no-account-found-error', 'no account found with this username..');
 redirect('login');
}
}




public function sessionDestroy() 
{
  if (!$this->session->userdata('username')) redirect('login');
  $this->session->set_flashdata('logout-success', 'logout successfully');
  // $this->session->unset_userdata('id');
  $this->session->unset_userdata('username');
  $this->session->unset_userdata('role');
  // $this->session->unset_userdata('name');
        //delete_cookie('remember_me_token');
  redirect('');
}
public function signUp()
{
	$this->load->view('library/signup');
}
public function adminHome()
{
  $this->load->view('admin/header');
	$this->load->view('admin/home');
   $this->load->view('admin/footer');
}
public function viewPost()
{
	$data['post_details'] = $this->Welcome_model->getPost();
  $this->load->view('admin/header');

	$this->load->view('admin/view_post',$data);
  $this->load->view('admin/footer');

}
public function addPost()
{
  $this->load->view('admin/header');
	$this->load->view('admin/post');
  $this->load->view('admin/footer');
}
public function insertPost()
{
	$this->Welcome_model->insertPost();
}
public function editPost($id)
{

	$data['singlePost'] = $this->Welcome_model->getPostDetails($id);
  $this->load->view('admin/header');
	$this->load->view('admin/edit_post', $data);		
$this->load->view('admin/footer');
}
public function updatePost($id){
	
  $this->load->view('admin/header');
  $this->Welcome_model->updatePost($id);
  $this->load->view('admin/footer');
}
public function deletePost($id){
	$this->Welcome_model->deletePost($id);
}
public function authorizeUser($id){
  $this->Welcome_model->authorizeUser($id);
}

// USers
public function viewUser()
{
  $data['user_details'] = $this->Welcome_model->getUser();
  $this->load->view('admin/header');
	$this->load->view('admin/view_user',$data);
  $this->load->view('admin/footer');
}
public function addUSer()
{
    $this->load->view('admin/header');
	$this->load->view('admin/user');
    $this->load->view('admin/footer');
}
public function insertUser()
{
	$this->Welcome_model->insertUser();
}
public function editUser($id)
{

	$data['singleUser'] = $this->Welcome_model->getUserDetail($id);
 $this->load->view('admin/header');
	$this->load->view('admin/edit_user', $data);		
  $this->load->view('admin/footer');

}
public function updateUser($id){
	$this->Welcome_model->updateUser($id);
}
public function deleteUser($id){
	
	$this->Welcome_model->deleteUser($id);
}



}?>