<!DOCTYPE html>
<html>
<head>
  <title>ADMIN PANEL</title>
  <meta name="robots" content="noindex, nofollow">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2">
  <link href="<?php echo base_url()?>admin/admin.css" rel="stylesheet">
  <link href="<?php echo base_url()?>assets/assets/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <!-- (B) NOW LOADING SPINNER -->
  <div id="page-loader">
    <img src="<?php echo base_url()?>admin/cube-loader.svg"/>
  </div>
  <!-- (C) SIDE BAR -->
  <nav id="page-sidebar">
    <a href="<?php echo base_url('admin-home')?>">
      DASHBOARD  
    </a>
    <a >
      <span class="ico"></span> <?php echo $this->session->userdata('fname')?> <?php echo $this->session->userdata('lname')?><?php if($this->session->userdata('role')==1) {?>
    <span >(ADMIN)</span>
    <?php }else {?>
       <span>(USER)</span>
       <?php } ?>
    </a>
   <?php if($this->session->userdata('role')==1){?> 
    <a href="<?php echo base_url('view-users')?>">
      <span class="ico">&#9879;</span> USERS
    </a>
<?php }?>
    <a href="<?php echo base_url('view-post')?>">
      <span class="ico">&#9880;</span> POSTS
    </a>
      <a href="<?php echo base_url('logout')?>">
      <span class="ico">&#9880;</span> LOGOUT
    </a>
     <!--  <a href="pageB.php">
        <span class="ico">&#9880;</span> RESOLVE
      </a> -->

    </nav>