
 <script src="<?php echo base_url()?>admin/admin.js"></script>
</body>
</html>