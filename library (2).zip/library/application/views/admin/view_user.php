


    <!-- (D) MAIN CONTENTS -->
    <div id="page-main">

      <!-- (D1) NAVIGATION BAR -->
      <nav id="page-nav" style="padding-top: 5px;">
        <div id="page-button-side" onclick="admin.sidebar();">&#9776;</div>
        <!-- <div id="page-button-out" onclick="admin.bye();">&#9747;</div> -->
        <h2 class="text-center">VIEW USERS</h2>
      </nav>


      <!-- (D2) PAGE CONTENTS -->
      <main id="page-contents">
       <!--  <div style="margin: 20px">
   
       </div> -->
       <div class="table-responsive" style="justify-content: center;">
        <table class="table">
         <a href="<?php echo base_url('add-user')?>">
          <button type="button" class="btn btn-primary btn-sm" style="float: right;">Add Post</button> 
        </a> 
        <thead>
          <tr>
           <th>Sl.No</th>
           <th>First Name</th>
           <th>Last Name</th>
           <th>Username</th>
           <th>Password</th>

           <th>Action</th>
         </tr>
       </thead>
       <tbody>
        <?php $i=1;
        foreach($user_details as $user): ?>
          <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $user->first_name; ?></td>
            <td><?php echo $user->last_name; ?></td>
            <td><?php echo $user->email; ?></td>
            <td><?php echo $user->password; ?></td>

            <td>
              <a href="<?php echo base_url('edit-user/'.$user->id)?>" style="padding: 10px"><button class="btn btn-primary btn-sm">Edit</button></a>
              <a href="<?php echo base_url('delete-user/'.$user->id)?>"><button class="btn btn-danger btn-sm">Delete</button></a>
            
                <?php if ($user->authorized==1) {?>
                   <button class="btn btn-success btn-sm">user is authorized</button>
                <?php }else{?>
                    <a href="<?php echo base_url('authorize-user/'.$user->id)?>"><button class="btn btn-primary btn-sm">Authroize this user</button>
                <?php }?>

              </a>
            </td>         
          </tr>
          <?php $i++; endforeach; ?>
        </tbody>
      </table>
    </div>
    
    <!-- <h2>DASHBOARD</h2> -->
  </main>
</div>

