    <!-- (D) MAIN CONTENTS -->
    <div id="page-main">
      <!-- (D1) NAVIGATION BAR -->
      <nav id="page-nav" style="padding-top: 5px;">
        <div id="page-button-side" onclick="admin.sidebar();">&#9776;</div>
       <div class="">
         <h2 class="text-center" >HOME</h2>
       </div>
   </nav>
   <!-- (D2) PAGE CONTENTS -->
 </div>
