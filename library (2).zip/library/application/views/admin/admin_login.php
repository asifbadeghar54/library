<!doctype html>
<html lang="en">
  <head>
   <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="PHILOSOPHY LIBRARY">
        <meta name="author" content="PHILOSOPHY LIBRARY">
        <meta name="generator" content="PHILOSOPHY LIBRARY">
      <title>PHILOSOPHY LIBRARY</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/headers/">

    

    <!-- Bootstrap core CSS -->
<link href="<?php echo base_url()?>assets/assets/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      .centerText {
        display: flex;
  justify-content: center;
}
    </style>

    
    <!-- Custom styles for this template -->
    <link href="headers.css" rel="stylesheet">
  </head>
  <body>
<div class="container-fluid centerText " style="margin-top:50px;margin-bottom:50px;">
  
      <div class="card ">  
   <div class="card-body ">
   
        <h2 class="text-center">Login</h2>
        <p class="text-center">Please fill in your credentials to login.</p>
        <form class="" action="<?php echo base_url('verify-admin-login')?>" method="post">
             <div class="row centerText">
             <div class="col-lg-12 col-md-12 col-sm-12 ">
            <div class="form-group">
                <label class="">Username</label>
                <input type="text" name="username" class="form-control " value="">
                <span class="invalid-feedback"></span>
            </div>  </div>  </div>
            <div class="row centerText">
             <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control ">
                <span class="invalid-feedback"></span>
            </div>
             </div>
              </div>
            <div class="form-group mt-3 ">
                <input type="submit" class="btn btn-primary" value="Login">
            </div>
            <p>Don't have an account? <a href="<?php echo base_url('sign-up')?>">Sign up now</a>.</p>
           
        </form>
         </div> 
</div>
 <script src="<?php echo base_url()?>assets/assets/dist/js/bootstrap.bundle.min.js"></script>

      
  </body>
</html>
