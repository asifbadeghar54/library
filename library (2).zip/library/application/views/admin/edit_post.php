


<!-- (D) MAIN CONTENTS -->
<div id="page-main">

  <!-- (D1) NAVIGATION BAR -->
  <nav id="page-nav" style="padding-top: 5px;">
    <div id="page-button-side" onclick="admin.sidebar();">&#9776;</div>
    <!-- <div id="page-button-out" onclick="admin.bye();">&#9747;</div> -->
    <h2 class="text-center">EDIT POST</h2>
</nav>
<div class="container" style="padding: 100px">
   <form method="post" id="editpost" name="editpost" action="<?php echo base_url('update-post/'.$this->uri->segment(2))?>">
      <div class="row">
        <div class="col-lg-6" style="padding: 10px">
          <label for="exampleFormControlInput1" class="form-label">Title</label>
          <input type="text" class="form-control" id="title" name="title" placeholder="Enter Title" value="<?php echo $singlePost->title?>">
      </div>
      <div class="col-lg-6" style="padding: 10px">
          <label for="exampleFormControlInput1" class="form-label">Content</label>
          <input type="text" class="form-control" id="content" name="content" placeholder="Enter Content" value="<?php echo $singlePost->content?>">
      </div>
      <div class="col-lg-6" style="padding: 10px">
          <label for="exampleFormControlInput1" class="form-label">Author</label>
          <input type="text" class="form-control" id="auther" name="auther" placeholder="Enter Auther Name" value="<?php echo $singlePost->auther?>">
      </div>
      <div class="col-lg-6" style="padding: 10px">
          <label for="exampleFormControlInput1" class="form-label">Date</label>
          <input type="date" class="form-control" id="date" name="date" placeholder="" value="<?php echo $singlePost->date?>">
      </div>
      <div class="col-lg-12" style="padding: 10px">
          <label for="exampleFormControlTextarea1" class="form-label">Description</label>
          <textarea class="form-control" id="description" name="description" rows="3" placeholder="Enter Description"><?php echo $singlePost->description?></textarea>
      </div>
  </div>
  <button type="submit" class="btn btn-primary ">Update</button>  
</form> 
</div>

<!-- (D2) PAGE CONTENTS -->
<main id="page-contents">

  <!-- <h2>DASHBOARD</h2> -->
</main>
</div>

<script type="text/javascript" src="//cdn.jsdelivr.net/jquery.bootstrapvalidator/0.5.0/js/bootstrapValidator.min.js"></script>




<script>
    $(document).ready(function() {
        $('#addPost').bootstrapValidator({
            
            feedbackIcons: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                title: {
                    message: 'The Meal type is not valid',
                    validators: {
                        notEmpty: {
                            message: 'Please enter Title'
                        },
                        
                    }
                },
                auther: {
                    message: 'The Meal type is not valid',
                    validators: {
                        notEmpty: {
                            message: 'Please Enter Auther Name'
                        },
                        
                    }
                },
                date: {
                    message: 'The Meal type is not valid',
                    validators: {
                        notEmpty: {
                            message: 'Please Enter Date'
                        },
                        
                    }
                },
                description: {
                    message: 'The Meal type is not valid',
                    validators: {
                        notEmpty: {
                            message: 'Please Enter Description'
                        },
                        
                    }
                },
                content: {
                    message: 'The Meal time is not valid',
                    validators: {
                        notEmpty: {
                            message: 'Please Enter Content'
                        },
                        
                    }
                },                                          
            }
        });
    });
</script>
