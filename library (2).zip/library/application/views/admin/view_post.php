


<!-- (D) MAIN CONTENTS -->
<div id="page-main">
  <!-- (D1) NAVIGATION BAR -->
  <nav id="page-nav" style="padding-top: 5px;">
    <div id="page-button-side" onclick="admin.sidebar();">&#9776;</div>
    <!-- <div id="page-button-out" onclick="admin.bye();">&#9747;</div> -->
    <h2 class="text-center">VIEW POST</h2>
  </nav>
  <!-- (D2) PAGE CONTENTS -->
  <main id="page-contents">
       <!--  <div style="margin: 20px">
       </div> -->
        <div class="container-fluid">
       <div class="table-responsive w-100 "style="justify-content: center !important;max-width: 800px;">
        <table class="table">
         <a href="<?php echo base_url('add-post')?>">
          <button type="button" class="btn btn-primary btn-sm" style="float: right;">Add Post</button> 
        </a> 
        <thead>
          <tr>
           <th>Sl.No</th>
           <th width="10%">Auther</th>
           <th width="10%">Title</th>
           <th width="10%">Content</th>
           <th width="50%">Description</th>
           <th width="10%">Date</th>
           <th>Action</th>
         </tr>
       </thead>
       <tbody>
        <?php $i=1;
        foreach($post_details as $post): ?>
          <tr>
          <td><?php echo $i; ?></td> 
            <td><?php echo $post->auther; ?></td>
            <td><?php echo $post->title; ?></td>
            <td><?php echo $post->content; ?></td>
           <td><?php echo $post->description; ?></td>
            <td><?php echo $post->date; ?></td>
            <td><a href="<?php echo base_url('edit-post/'.$post->id)?>" ><button class="btn btn-primary btn-sm" style="margin: 5px">Edit</button></a>
             <?php if($this->session->userdata('role')==1){?> 
              <a href="<?php echo base_url('delete-post/'.$post->id)?>"><button class="btn btn-danger btn-sm">Delete</button></a><?php }?>
            </td>         
          </tr>
          <?php $i++; endforeach; ?>
        </tbody>
      </table>
    </div>
     </div>
    <!-- <h2>DASHBOARD</h2> -->
  </main>
</div>


