<?php
    include_once("functions.php");
    
    $dbconnect = dblink();

    if ($dbconnect) {
        echo "<!-- Established Connection -->";

    }
    //ShowMEM();

    $id = $_GET['id'];

    $sql = "SELECT * FROM users WHERE id=$id";
    $result=mysqli_query($dbconnect,$sql);
    if (mysqli_num_rows($result)>0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $fname = $row['firstname'];
            $lname = $row['lastname'];
            $uname = $row['username'];
            $pwd = $row['password'];            
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="resolve.php" method="post">
    <input type="text" name="fname" value="<?php echo $fname;?>">
    <input type="text" name="lname" value="<?php echo $lname;?>">
    <input type="text" name="uname" value="<?php echo $uname;?>">
    <input type="text" name="pwd" value="<?php echo $pwd;?>">
    <input type="hidden" name="id" value="<?php echo $id;?>">
    <input type="submit" value="update">


    </form>
    <hr>
    <a href="index.php">Return Home</a>

    
</body>
</html>