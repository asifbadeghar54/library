<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="keywords" content="Defence Housing Co-operative Society ">
	<meta name="Description" content="">
	<meta name="author" content="Team Creatinno">
	<meta name="theme-color" content="#ffffff"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/all.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/style.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/hide.css">
	<link rel="stylesheet" href="<?php echo base_url()?>assets/animate/animate.css">
	<link rel="stylesheet" href="<?php echo base_url()?>assets/owl-carousel/css/owl.carousel.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
	<link rel="icon" type="image/x-icon" href="<?php echo base_url()?>assets/images/fevicon.png">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@500;700&display=swap">
	<link href="https://fonts.googleapis.com/css2?family=Newsreader:ital,wght@0,600;1,500&display=swap" rel="stylesheet">

  <link href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap4.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
 <!--  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script> -->
</head>

<body>
  <button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fas fa-arrow-up"></i></button>
  <div class="header1">
    <div class="container-fluid">
      <div class="row">
        <div class="col-xxl-2 col-xl-2 col-lg-3 col-md-3 col-sm-3 col-4">
          <div class="logo">
            <img src="<?php echo base_url()?>assets/images/logo200.png">
          </div>
        </div>
        <!-- end of logo -->
        <div class="col-xxl-7 col-xl-7 col-lg-7 col-md-6 col-sm-6 col-8">
          <div class="logotext">
            <p class="kan">ಡಿಫೆನ್ಸ್ ಹ್ಯಾಬಿಟಾಟ್ ಹೌಸಿಂಗ್ ಕೋ-ಆಪರೇಟಿವ್ ಸೊಸೈಟಿ ಲಿ.</p>
            <p style="margin-top: -15px;">DEFENCE HABITAT HOUSING CO-OPERATIVE SOCIETY LTD.</p>
            <h5 class="reg">Reg. No.:- HSG-3/64/HHS/53744 </h5>
          </div>
        </div>
        <!-- end of logo text -->
        <div class="col-xxl-3 col-xl-3 col-lg-2 col-md-3 col-sm-3 col-12">
        <!--<div class="logobuttons">
          <a href="latestnews"><button class="btn1">Latest News</button></a>
          <a href=""><button class="btn1">Member Login</button></a>
        </div>
      </div>-->
      <!-- end of logo text -->
    </div>
  </div>
</div>
<!-- end of header -->

<div class="nav">

	<!-- toggle class -->
  <div class="toggle">
   <div class="logo2">
    <h2>Menu</h2>
  </div>
  <i class="fa fa-bars menu" aria-hidden="true">		
  </i>

</div>
<!-- end of toggle class -->
<div class="clearfix"></div>
<div class="container-fluid">
  <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12">
    <div class="topnav active2 navbar-collapse">
      <ul>
        <li>
          <a href="<?php echo base_url()?>">Home</a>
        </li>
        <li>
          <a href="#" class="dropdown">Projects</a>
          <ul class="dropdown1">
            <li>
              <a href="<?php echo base_url('addprojects')?>">ADD PROJECT</a>
            </li>
            <li>
              <a  href="addnewplots">PLOT SIZE</a>
            </li>
            <li>
              <a href="<?php  echo base_url('addlanddetails')?>">ADD LAND DETAILS</a>
            </li>
              <!--   <li>
                  <a  href="viewlanddetails">VIEW LAND DETAIL</a>
                </li> -->
                <li>
                  <a href="<?php  echo base_url('addprojectstatus')?>">ADD PROJECT STATUS</a>
                </li>
                <li>
                  <a  href="<?php  echo base_url('projectstatushistory')?>">PROJECT STATUS HISTORY</a>
                </li>
              </ul>
            </li>
            <li>
              <a href="#" class="dropdown2">Members</a>
              <ul class="dropdow2">
                <li>
                  <a href="<?php echo base_url('addmembers')?>">ADD</a>
                </li>
                <li>
                  <a  href="<?php echo base_url('viewmembers')?>">VIEW</a>
                </li>
                <li>
                  <a  href="<?php echo base_url('transferplot')?>">TRANSFER PLOT</a>
                </li>
                <li>
                  <a  href="<?php echo base_url('viewplottransferhistory')?>">VIEW TRANSFERED PLOT HISTORY</a>
                </li>
                <li>
                  <a  href="<?php echo base_url('addmemberextracharges')?>">ADD EXTRA CHARGES</a>
                </li>
                <li>
                  <a  href="<?php echo base_url('viewmemberextracharges')?>">VIEW EXTRA CHARGES</a>
                </li>
                <li>
                  <a  href="<?php echo base_url('transferplot')?>">VIEW INACTIVE MEMBERS</a>
                </li>
                <li>
                  <a  href="<?php echo base_url('plotcancel')?>">CANCEL PLOT</a>
                </li>
                <li>
                  <a  href="<?php echo base_url('viewcanceledplots')?>">VIEW CANCELLED PLOT MEMBERS</a>
                </li>
                <li>
                  <a  href="<?php echo base_url('viewmembersdetails')?>">VIEW MEMBER DETAILS</a>
                </li>
              </ul>
            </li>
            <li>
              <a href="#" class="dropdown3">Employee</a>
              <ul class="dropdow3">
                <li>
                  <a href="<?php echo base_url('addemployee')?>">Add Employee</a>
                </li>
                <li>
                  <a  href="<?php echo base_url('viewemployee')?>">View Employee</a>
                </li>
              </ul>
            </li>
            <li>
              <a href="#" class="dropdown4">Reciept</a>
              <ul class="dropdow4">
                <li>
                  <a href="<?php echo base_url('view_reciept')?>">View Reciept</a>
                </li>
                <li>
                  <a  href="<?php echo base_url('view_site_booking_affidivate')?>">View Site Booking & Affidivate</a>
                </li>
                <li>
                  <a  href="<?php echo base_url('view_share_certificate ')?>">View Share Certificate</a>
                </li>
              </ul>
            </li>
            <li>
              <a href="reports">Reports</a>
            </li>
            <li>
              <a href="<?php echo base_url('application_download_details')?>">Download Application</a>
            </li>
            <li>
              <a href="<?php echo base_url('contactmembers')?>">Contact members</a>
            </li>
            <li>
              <a href="#" class="dropdown5">Reminder</a>
              <ul class="dropdow5">
                <li>
                  <a href="<?php echo base_url('addreminder')?>">Add Reminder</a>
                </li>
                <li>
                  <a  href="<?php echo base_url('viewreminder')?>">View Reminder</a>
                </li>
              </ul>
            </li>
            <li>
              <a href="#" class="dropdown6">Settings</a>
              <ul class="dropdow6">
                <li>
                  <a href="<?php echo base_url('account')?>">Account</a>
                </li>
                <li>
                  <a  href="<?php echo base_url('dimension')?>">Dimension</a>
                </li>
                <li>
                  <a  href="<?php echo base_url('installment')?>">Installment</a>
                </li>
                <li>
                  <a  href="<?php echo base_url('advanced_amount')?>">Advanced Amount</a>
                </li>
                <li>
                  <a  href="<?php echo base_url('extra_charges')?>">Extra Charges</a>
                </li>
                <li>
                  <a  href="<?php echo base_url('receipt_amount')?>">Receipt Amount</a>
                </li>
                <!--<li>-->
                  <!--  <a  href="<?php echo base_url('log_report')?>">Log Report</a>-->
                  <!--</li>-->
                  <!--<li>-->
                    <!--  <a  href="<?php echo base_url('change_employee_password')?>">Change Employee Password</a>-->
                    <!--</li>-->
                    <!--<li>-->
                      <!--  <a  href="<?php echo base_url('view_inactive_receipt')?>">View Inactive Receipt</a>-->
                      <!--</li>-->
                      <li>
                        <a  href="<?php echo base_url('project_city_name')?>">Project City Name</a>
                      </li>
                      <!--<li>-->
                        <!--  <a  href="<?php echo base_url('change_your_password')?>">Change Your Password</a>-->
                        <!--</li>-->
                      </ul>
                    </li>
                    <li>
                      <a href="contactus">Logout</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

