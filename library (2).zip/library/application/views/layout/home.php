<!doctype html>
  <html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="PHILOSOPHY LIBRARY">
    <meta name="author" content="PHILOSOPHY LIBRARY">
    <meta name="generator" content="PHILOSOPHY LIBRARY">
    <title>PHILOSOPHY LIBRARY</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/headers/">



    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url()?>assets/assets/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
      .hero{
        background-image: url("assets/images/nv.jpg");
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        background-attachment: fixed;

        height: 60vh;
        color: white;
      }
    </style>
    <!-- Custom styles for this template -->
    <link href="headers.css" rel="stylesheet">
  </head>
  <body>
    <main style="background-color: lightgreen;">
      <div class="container-fluid">
        <header class="w-100 hero d-flex flex-wrap justify-content-center border-bottom">
          <h1 class="fs-2 text-white float-left " style="font-family: italic;"><b>PHILOSOPHY LIBRARY</b></h1>
          <a href="<?php echo base_url()?>" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
            <!-- <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"/></svg> -->
          </a>
          <ul class="nav nav-pills">
            <li class="nav-item"><a href="#" class="nav-link active" aria-current="page">Home</a></li>&nbsp;
            <!-- <li class="nav-item"><a href="#" class="nav-link">Posts</a></li> -->
            <li class="nav-item"><a href="<?php echo base_url('login')?>" class="nav-link active">POST</a></li>&nbsp;
            <li class="nav-item"><a href="<?php echo base_url('login')?>" class="nav-link active">Login</a></li>
          </ul>
        </header>
        </div>
        <div class="container-fluid">
        <div class="row mt-4">
          <?php foreach($post_details as $post): ?>
           <div class="col-lg-12 text-white">
            <div class="card bg-success" style="margin-bottom: 10px">
              <div class="card-body">
                <h5 class="card-title"><?php echo $post->title; ?></h5>
                <p><?php echo $post->auther; ?><br>
                 <?php echo $post->content; ?><br>
                 <?php echo $post->description; ?><br>
                 <?php echo $post->date; ?></p>
               </div>   
             </div>
           </div>
         <?php endforeach; ?>

       </div></div>
     
   </main>






   <script src="<?php echo base_url()?>assets/assets/dist/js/bootstrap.bundle.min.js"></script>
    <footer style="background-color: black;">
      <div>
        copy right @2021 
      </div>
    </footer>

 </body>
 </html>
