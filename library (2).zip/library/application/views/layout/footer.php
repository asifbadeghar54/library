<footer>
  <div class="copyrights">
    <div class="container-fluid">
      <div class="row">
        <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
          <div class="copy">
            <p>© 2021 DEFENCE HABITAT All Right Reserved.</p>
          </div>
        </div>
        <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
          <div class="creatinno">
          <p>Powered By <a href="https://creatinno.in"><span class="ciblue">creat</span><span class="ciorange">inno</span></a></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>
  <!-- scripts -->
  <!-- bootstrap min -->
  <script  src="<?php echo base_url()?>assets/js/bootstrap.js"></script>
  <!-- js jquery -->
  <script  src="<?php echo base_url()?>assets/js/all.js"></script>
  <!-- js 3.3.1 -->
  <script src="<?php echo base_url()?>assets/js/jquery-3.5.1.js"></script>

    <script src="<?php echo base_url()?>assets/js/scripts.js"></script>
    <script src="<?php echo base_url()?>assets/owl-carousel/js/owl.carousel.min.js"></script>

  <script src="<?php echo base_url()?>assets/wow/wow.min.js"></script>

   <script src="https://code.jquery.com/jquery-3.5.1.js"></script> 
 <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script> 
 <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script> 
  <!-- end of scripts -->
  <script>
//Get the button
var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
  </body>
</html>